# OSAM
![GitHub Logo](/Graphics/Pictures/TitleLogo.png)

Oneshot Aftermath is a post solstice mod taking place a year after the original events of a solstice run in which place Niko is returned to the world of Oneshot still filled with sunlight until the sun is stolen making you and Niko embark on a new journey to save the world


__Status__
`1 Demo`

__New Additions__

- *New story*
-  *New Characters* 
- *Custom Achievements*
- *All New Maps*
- *New Areas*
- *New Music*
-*New Puzzles*

`Other Places To Follow Development`


[Discord](https://discord.gg/Qh4uQKs)

[Tumblr Devlog](https://cryrocat.tumblr.com/)

[Youtube](https://www.youtube.com/channel/UCPFwqZO2XsdXtWPKQRxpW )

[Twitter](https://twitter.com/CatCryro) - I mostly just retweet the heck out of furry art there though...

[Donations](https://streamlabs.com/uknowdgaming) - If you want to I guess 
